<?php

/**
 * Trigger this file on plugin uninstall
 * 
 * @package tenup
 */

 if(! defined('WP_UNINSTALL_PLUGIN')) {
     die;
 }

 //Clear database stored data
//  $categories = get_categories(array('hide_empty' => false, 'child_of' => 10)); 

// Access the database via SQL
global $wpdb;
// $wpdb->query("DELETE FROM wp_posts WHERE post_type = 'book'");
$wpdb->query("DELETE FROM wp_postmeta WHERE post_id NOT IN (SELECT id FROM wp_posts)");
$wpdb->query("DELETE FROM wp_postmeta WHERE meta_key='tenup_primary_category'");
// $wpdb->query("DELETE FROM wp_term_relationships WHERE object_id NOT IN (SELECT id FROM wp_posts)");